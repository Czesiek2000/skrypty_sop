#ifndef __EKG_NCURSES_COMPLETION_H
#define __EKG_NCURSES_COMPLETION_H

void ncurses_complete(int *line_start, int *line_index, char *line);
void ncurses_complete_clear();

#endif

/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
