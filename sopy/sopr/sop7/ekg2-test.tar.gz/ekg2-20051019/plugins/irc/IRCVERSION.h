#define IRCVERSION "0.8.cvs"

#ifndef IRCVERSION
#include "ircversion.h"
#endif

/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
