#include "../common/module.h"

#include "../../irc/misc.h"
#include "../../irc/irc.h"

typedef channel_t *Ekg2__Irc__Channel;
typedef people_t  *Ekg2__Irc__User;
typedef session_t  *Ekg2__Irc__Server;
