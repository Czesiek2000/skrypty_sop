/* variables */
char	*xosd_colour;
char 	*xosd_font;
char 	*xosd_outline_colour;
char 	*xosd_shadow_colour;

int 	xosd_display_filter;
int 	xosd_display_notify;
int 	xosd_display_timeout;
int 	xosd_display_welcome;
int 	xosd_horizontal_offset;
int	xosd_horizontal_position;
int 	xosd_outline_offset;
int 	xosd_shadow_offset;
int 	xosd_short_messages;
int 	xosd_text_limit;
int 	xosd_vertical_offset;
int 	xosd_vertical_position;
