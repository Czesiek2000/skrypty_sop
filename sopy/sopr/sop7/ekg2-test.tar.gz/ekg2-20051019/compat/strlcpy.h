#include <sys/types.h>

size_t strlcpy(char *dst, const char *src, size_t size);

/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
