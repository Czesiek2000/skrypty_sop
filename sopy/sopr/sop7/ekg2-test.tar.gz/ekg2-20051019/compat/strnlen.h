#include <sys/types.h>

size_t strnlen(const char *s, size_t n);



/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
