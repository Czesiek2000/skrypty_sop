#include <sys/types.h>
#include <stdlib.h>
#include <string.h>

char *strndup(char *s, size_t n);


/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
