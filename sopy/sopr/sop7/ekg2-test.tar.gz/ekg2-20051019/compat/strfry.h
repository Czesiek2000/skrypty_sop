
#ifndef EKG2_COMPAT_STRFRY_H
#define EKG2_COMPAT_STRFRY_H

char* strfry(char*);

#endif

/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
