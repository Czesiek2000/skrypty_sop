/* $Id: debug.h,v 1.4 2004/11/02 13:38:28 mp Exp $ */

#ifndef __EKG_DEBUG_H
#define __EKG_DEBUG_H

void debug(const char *format, ...);

#endif


/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
