/* $Id: sessions.h,v 1.24 2005/09/18 22:48:44 gim Exp $ */

/*
 *  (C) Copyright 2003 Wojtek Kaniewski <wojtekka@irc.pl>
 * 		  2004 Piotr Kupisiewicz <deli@rzepaknet.us>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License Version 2 as
 *  published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef __EKG_SESSIONS_H
#define __EKG_SESSIONS_H

#include <time.h>
#include "dynstuff.h"

list_t sessions;

typedef struct {
	char *key;			/* nazwa parametru */
	char *value;			/* warto�� parametru */
} session_param_t;

typedef struct {
	/* public: */
	char *uid;			/* id u�ytkownika */
	char *alias;			/* alias sesji */
	void *priv;			/* dla plugina obs�uguj�cego sesj� */
	list_t userlist;		/* userlista */

	/* private: */
	char *status;			/* stan sesji */
	char *descr;			/* opis stanu sesji */
	char *password;
	int connected;			/* czy sesja jest po��czona? */
	int activity;			/* kiedy ostatnio co� si� dzia�o? */
	int autoaway;			/* jeste�my w autoawayu? */
	int scroll_last;
	int scroll_pos;
	int scroll_op;
	time_t last_conn;               /* kiedy si� po��czyli�my */
	list_t params;
} session_t;

session_t *session_current;

session_t *session_find(const char *uid);
session_param_t *session_var_find(session_t *s, const char *key);

int session_var_default(session_t *s);
#define session_var_default_n(a) session_var_default(session_find(a))

int session_is_var(session_t *s, const char *key);

const char *session_uid_get(session_t *s);
#define session_uid_get_n(a) session_uid_get(session_find(a))

const char *session_alias_get(session_t *s);
#define session_alias_get_n(a) session_alias_get(session_find(a))
int session_alias_set(session_t *s, const char *alias);
#define session_alias_set_n(a,b) session_alias_set(session_find(a),b)

const char *session_status_get(session_t *s);
#define session_status_get_n(a) session_status_get(session_find(a))
int session_status_set(session_t *s, const char *status);
#define session_status_set_n(a,b) session_status_set(session_find(a),b)

const char *session_descr_get(session_t *s);
#define session_descr_get_n(a) session_descr_get(session_find(a))
int session_descr_set(session_t *s, const char *descr);
#define session_descr_set_n(a,b) session_descr_set(session_find(a),b)

const char *session_password_get(session_t *s);
#define session_password_get_n(a) session_descr_get(session_find(a))
int session_password_set(session_t *s, const char *password);
#define session_password_set_n(a,b) session_descr_set(session_find(a),b)

void *session_private_get(session_t *s);
#define session_private_get_n(a) session_private_get(session_find(a))
int session_private_set(session_t *s, void *priv);
#define session_private_set_n(a,b) session_private_set(session_find(a),b)

int session_connected_get(session_t *s);
#define session_connected_get_n(a) session_connected_get(session_find(a))
int session_connected_set(session_t *s, int connected);
#define session_connected_set_n(a,b) session_connected_set(session_find(a),b)

const char *session_get(session_t *s, const char *key);
#define session_get_n(a,b) session_get(session_find(a),b)
int session_int_get(session_t *s, const char *key);
#define session_int_get_n(a,b) session_int_get(session_find(a),b)
int session_set(session_t *s, const char *key, const char *value);
#define session_set_n(a,b,c) session_set(session_find(a),b,c)
int session_int_set(session_t *s, const char *key, int value);
#define session_int_set_n(a,b,c) session_int_set(session_find(a),b,c)

const char *session_format(session_t *s);
#define session_format_n(a) session_format(session_find(a))

/* alias or uid - formatted */
const char *session_name(session_t *s);
#define session_name_n(a) session_name(session_find(a))

/* alias or uid - not formatted */
#define session_alias_uid(a) (a->alias) ? a->alias : a->uid
#define session_alias_uid_n(a) session_alias_uid(session_find(a))

int session_check(session_t *s, int need_private, const char *protocol);
#define session_check_n(a,b,c) session_check(session_find(a),b,c)

int session_unidle(session_t *s);
#define session_unidle_n(a) session_unidle(session_find(a))

int session_compare(void *data1, void *data2);
session_t *session_add(const char *uid);
int session_remove(const char *uid);
#define session_remove_s(a) session_remove(a->uid)

int session_read();
int session_write();

void sessions_free();

void session_help(session_t *s, const char *name);
#endif /* __EKG_SESSIONS_H */

/*
 * Local Variables:
 * mode: c
 * c-file-style: "k&r"
 * c-basic-offset: 8
 * indent-tabs-mode: t
 * End:
 */
